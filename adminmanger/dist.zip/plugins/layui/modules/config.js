layui.define(['table'], function(exports) {
    var config = { //张
        serverUrl: function() {
            return "http://192.168.1.215/cherrytea-admin/";
        },
        uploadFileUrl: function() {
            return "http://192.168.1.215/cherrytea-admin/";
        },
        imgUrl: function() {
            return "http://192.168.1.215/cherrytea-admin/";
        }
    }

    // var config = { //谭
    //     serverUrl: function() {
    //         return "http://192.168.1.215/cherrytea-admin/";
    //     },
    //     uploadFileUrl: function() {
    //         return "http://192.168.1.215/cherrytea-admin/";
    //     },
    //     imgUrl: function() {
    //         return "http://192.168.1.215/cherrytea-admin/";
    //     }
    // }

    exports('config', config);
});